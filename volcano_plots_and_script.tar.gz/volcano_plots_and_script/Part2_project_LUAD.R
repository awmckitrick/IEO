#################
## Charge modules
#################
library(knitr)
library(SummarizedExperiment)
library(edgeR)
library(ggplot2)
library(plyr)
library(sva)
library(grid)
library(geneplotter)
library(limma)

##################
## Initialize data
##################

# Charge data
se <- readRDS( "seLUAD.rds")
dge_luad <- DGEList(counts = assays(se)$counts, genes = as.data.frame(mcols(se)), group = se$type)

# Logaritmize
CPM <- t(t(dge_luad$counts)/(dge_luad$samples$lib.size/1e+06))
assays(se)$logCPM <- cpm(dge_luad, log = TRUE, prior.count = 0.25)
assays(se)$logCPM[1:3, 1:7]

# Apply filters
cpmcutoff <- round(10/min(dge_luad$sample$lib.size/1e+06), digits = 1)
cpmcutoff

nsamplescutoff <- min(table(se$type))
nsamplescutoff

mask <- rowSums(cpm(dge_luad) > cpmcutoff) >= nsamplescutoff

se.filt <- se[mask, ]
dge_luad.filt <- dge_luad[mask, ]
dim(se.filt)

# Normalize
dge_luad.filt <- calcNormFactors(dge_luad.filt, normalize.method="quantile")

# Batch effect variables
tss <- substr(colnames(se.filt), 6, 7)
center <- substr(colnames(se.filt), 27, 28)
plate <- substr(colnames(se.filt), 22, 25)
portionanalyte <- substr(colnames(se.filt), 18, 20)
samplevial <- substr(colnames(se.filt), 14, 16)
gender <- unname(se.filt$gender)
race <- unname(se.filt$race)
histo <- unname(se.filt$histologic_diagnosis.1)

# Removing batch effect
#logCPM <- cpm(dge_luad.filt, log=TRUE, prior.count = 3)
#batch <- as.integer(factor(samplevial))
#logCPM.batch <- logCPM
#logCPM <-removeBatchEffect(logCPM, batch, design = mod)
#assays(se.filt)$logCPM <- logCPM
#s <- fast.svd(t(scale(t(logCPM), center = TRUE, scale = TRUE)))
#pcSds <- s$d
#pcSds[1] <- 0
#svdexp <- s$u %*% diag(pcSds) %*% t(s$v)
#colnames(svdexp) <- colnames(se.filt)
#d <- as.dist(1-cor(svdexp, method="spearman"))
#sampleClustering <- hclust(d)
#sampleDendrogram <- as.dendrogram(sampleClustering, hang=0.1)
#names(outcome) <- colnames(se.filt)

##########################
## DIfferential expression
##########################

# 1. Create SVA models
mod <- model.matrix(~ se.filt$type, colData(se.filt))
mod0 <- model.matrix(~ 1, colData(se.filt))
pv <- f.pvalue(assays(se.filt)$logCPM, mod, mod0)
sum(p.adjust(pv, method = "bonferroni") < 0.01)

sv <- sva(assays(se.filt)$logCPM, mod, mod0)
sv$n

modsv <- cbind(mod, sv$sv)
mod0sv <- cbind(mod0, sv$sv)
pvsv <- f.pvalue(assays(se.filt)$logCPM, mod, mod0)
sum(p.adjust(pvsv, method="bonferroni") < 0.01)

v <- voom(dge_luad.filt, mod, plot=TRUE)

#2. Fit linear model
fit5 <- lmFit(v, mod)
fit5sv <- lmFit(v,modsv)

#3. T-statistics
fit5 <- eBayes(fit5)
fit5sv <- eBayes(fit5sv)

#4. Extend of differencial expression
FDRcutoff <- 0.05
res5 <- decideTests(fit5, p.value = FDRcutoff)
summary(res5)
res5sv <- decideTests(fit5sv, p.value = FDRcutoff)
summary(res5sv)


#5. Metadata and fetch table
genesmd <- data.frame(
  chr = as.character(seqnames(rowRanges(se.filt))),
  symbol = rowData(se.filt)[, 1],
  stringsAsFactors = FALSE) # We have to say explicitly metadata is not a factor
fit5$genes <- genesmd
tt5 <- topTable(fit5, coef = 2, n = Inf)
head(tt5)

genesmd <- data.frame(
  chr = as.character(seqnames(rowRanges(se.filt))),
  symbol = rowData(se.filt)[, 1],
  stringsAsFactors = FALSE) # We have to say explicitly metadata is not a factor
fit5sv$genes <- genesmd
tt5sv <- topTable(fit5sv, coef = 2, n = Inf)
head(tt5sv)

#6. Chromosome distribution
sort(table(tt5$chr[tt5$adj.P.Val < FDRcutoff]), decreasing = TRUE)
sort(table(tt5sv$chr[tt5sv$adj.P.Val < FDRcutoff]), decreasing = TRUE)

#8. Diagnostic plots
par(mfrow = c(1, 2), mar = c(4, 5, 2, 2))
hist(tt5$P.Value, xlab = "Raw P-values", main = "", las = 1)
qqt(fit5$t[, 2], df = fit5$df.prior + fit5$df.residual, main = "", pch = ".", cex = 3)
abline(0, 1, lwd = 2)

pvsv <- f.pvalue(assays(se.filt)$logCPM, modsv, mod0sv)
sum(p.adjust(pvsv, method="bonferroni") < 0.01)

par(mfrow = c(1, 2), mar = c(4, 5, 2, 2))
hist(tt5sv$P.Value, xlab = "Raw P-values", main = "", las = 1)
qqt(fit5sv$t[, 2], df = fit5sv$df.prior + fit5sv$df.residual, main = "", pch = ".", cex = 3)
abline(0, 1, lwd = 2)

pvsv <- f.pvalue(assays(se.filt)$logCPM, modsv, mod0sv)
sum(p.adjust(pvsv, method="bonferroni") < 0.01)


# 9. Volcano plot
par(mfrow = c(1,2))
volcanoplot(fit5, coef = 2,
            highlight = 10,
            names = fit5$genes$symbol,
            main = "Model fit5",
            las = 1)
volcanoplot(fit5sv, coef = 2,
            highlight = 10,
            names = fit5sv$genes$symbol,
            main = "Model fit5 sva",
            las = 1)

# Looking for replicated data
table(table(se.filt$tissue_source_site))

################################
## Gene enrichment (Fisher test)
################################

geneUniverse <- rownames(se)
DEgenes <- rownames(tt5)[tt5$adj.P.Val < 0.01 & tt5$logFC < 0]

# 1. Prepare parameter used
library(GOstats)
params <- new("GOHyperGParams",
              geneIds=DEgenes,
              universeGeneIds=geneUniverse,
              annotation="org.Hs.eg.db",
              ontology="BP",
              pvalueCutoff=0.05,
              testDirection="over")

# 2. Functional enrichment analysis
hgOver <- hyperGTest(params)
hgOver

#3. Store and visualize results
htmlReport(hgOver, file = "gotests.html")#Not working for version problems
browseURL("gotests.html")

summary(hgOver)

# 3b. output results
head(geneCounts(hgOver))

head(universeCounts(hgOver))

head(pvalues(hgOver))

# COnditional testing
conditional(params) <- TRUE
hgOverCond <- hyperGTest(params)
hgOverCond
htmlReport(hgOverCond, file = "goconditionaltests.html")
browseURL("goconditionaltests.html")

###### Intepreting table
#Check
goresults <- summary(hgOverCond)
head(goresults)

#Filter to size between 3-300 and Mmore than 3 counts
goresults <- goresults[goresults$Size >= 3 & goresults$Size <= 300 & goresults$Count >= 3, ]
goresults <- goresults[order(goresults$OddsRatio, decreasing=TRUE), ]
head(goresults)

# Extract genes that enrich GO terms and paste them to results
geneIDs <- geneIdsByCategory(hgOverCond)[goresults$GOBPID]
geneSYMs <- sapply(geneIDs, function(id) select(org.Hs.eg.db, columns = "SYMBOL", key = id, 
                                                keytype = "ENTREZID")$SYMBOL)
geneSYMs <- sapply(geneSYMs, paste, collapse = ", ")
goresults <- cbind(goresults, Genes = geneSYMs)
rownames(goresults) <- 1:nrow(goresults)

library(xtable)
xtab <- xtable(goresults, align = "l|c|r|r|r|r|r|p{3cm}|p{3cm}|")
print(xtab, file = "goresults.html", type = "html")
